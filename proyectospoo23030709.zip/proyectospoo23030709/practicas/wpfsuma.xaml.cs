﻿using practica01;
using practicas02;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace proyectospoo23030709.practicas
{
    /// <summary>
    /// Lógica de interacción para wpfsuma.xaml
    /// </summary>
    public partial class wpfsuma : Window
    {
        public wpfsuma()
        {
            InitializeComponent();
        }

     
            public void btnsuma_Click(object sender, RoutedEventArgs e)
            {
                  Class1 op = new Class1();

                op.valor1 = decimal.Parse(txtvalor1.Text);
                op.valor2 = decimal.Parse(txtvalor2.Text);

                txtresultado.Text = op.suma().ToString();
            }

            private void btnresta_Click(object sender, RoutedEventArgs e)
            {
                Class1 op = new Class1();

                op.valor1 = decimal.Parse(txtvalor1.Text);
                op.valor2 = decimal.Parse(txtvalor2.Text);

                txtresultado.Text = op.resta().ToString();
            }

            private void btnmultiplica_Click(object sender, RoutedEventArgs e)
            {
                Class1 op = new Class1();

                op.valor1 = decimal.Parse(txtvalor1.Text);
                op.valor2 = decimal.Parse(txtvalor2.Text);

                txtresultado.Text = op.multiplicacion().ToString();
            }

            private void btndivision_Click(object sender, RoutedEventArgs e)
            {
            Class1 op = new Class1();

                op.valor1 = decimal.Parse(txtvalor1.Text);
                op.valor2 = decimal.Parse(txtvalor2.Text);

                txtresultado.Text = op.division().ToString();
            }

        private void txtvalor1_KeyDown(object sender, KeyEventArgs e)
        {
            // Permitir números del teclado principal (D0 - D9) y del teclado numérico (NumPad0 - NumPad9)
            if ((e.Key >= Key.D0 && e.Key <= Key.D9) ||
                (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9) ||
                e.Key == Key.Decimal ||
                e.Key == Key.OemPeriod || // Punto en algunos teclados
                e.Key == Key.Back ||      // Para permitir el uso de la tecla de retroceso
                e.Key == Key.Tab)         // Para permitir el uso de la tecla Tab
            {
                e.Handled = false;
            }
            else
            {
                MessageBox.Show("Introduzca solo números o decimales.");
                e.Handled = true;
            }
        }

        private void txtvalor2_KeyDown(object sender, KeyEventArgs e)
        {
            // Misma validación que para txtvalor1
            if ((e.Key >= Key.D0 && e.Key <= Key.D9) ||
                (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9) ||
                e.Key == Key.Decimal ||
                e.Key == Key.OemPeriod ||
                e.Key == Key.Back ||
                e.Key == Key.Tab)
            {
                e.Handled = false;
            }
            else
            {
                MessageBox.Show("Introduzca solo números o decimales.");
                e.Handled = true;
            }
        }

    }
}

