﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practica01
{
    internal class CLOPeraciones
    {
        public decimal valor1;
        public decimal valor2;

        public CLOPeraciones(decimal valor1, decimal valor2)
        {
            this.valor1 = valor1;
            this.valor2 = valor2;
        }

        public CLOPeraciones()
        {
        }

        //propiedades get,set

        //constructores

        //lo que hace (acccion)
        public decimal suma()
        {
            return (valor1 + valor2);
        }
    }
}
