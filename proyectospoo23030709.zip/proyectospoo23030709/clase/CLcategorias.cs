﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace proyectospoo23030709.clase
{
    internal class CLcategorias
    {
        private int CategoryID;private string Categoryname;private string Description; private byte[] picture;

        public CLcategorias() 
        {
            //mostrar todos los datos de la tabla
           
        }
        public CLcategorias (int CategoryID)
        {
            //consultar un solo registro por categoryID
            this.CategoryID = CategoryID;
        }

        public CLcategorias(int categoryID, string categoryname, string description, byte[] picture)
        {
            //grabar o modificar los datos del registro
            CategoryID = categoryID;
            Categoryname = categoryname;
            Description = description;
            this.picture = picture;
        }
        //procedimientos
        
        //buscar individualmente
        public string buscarindividual()
        {
            return ("select * from categories where CategoryID = '" + this.CategoryID + "'");
        }

        //buscar todos
        
        //grabar        

        //eliminar
    }
}
