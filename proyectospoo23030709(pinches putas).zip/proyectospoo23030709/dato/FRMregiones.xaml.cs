﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace proyectospoo23030709.dato
{
    /// <summary>
    /// Lógica de interacción para FRMregiones.xaml
    /// </summary>
    public partial class FRMregiones : Window
    {
        public FRMregiones()
        {
            InitializeComponent();
            cargarfolio();
        }
        private void cargarfolio()
        {
            // consulta sql
            //string sql = "SELECT MAX(RegionID) + 1 AS folio FROM Region";
            using (SqlConnection conn = new SqlConnection(clase.clglobales.globales.miconexion))
            {
                SqlCommand cmd = new SqlCommand("SP_folio_region", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                conn.Open();

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows) // Verifica si hay filas
                {
                    if (reader.Read()) // Lee la primera fila
                    {
                        if (!reader.IsDBNull(reader.GetOrdinal("folio"))) // Verifica si el valor no es nulo
                        {
                            this.txtID.Text = reader["folio"].ToString(); // Accede a la columna "folio"
                        }
                        else
                        {
                            MessageBox.Show("El campo 'folio' es nulo.");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("No se encontraron resultados.");
                }

                reader.Close(); // Cierra el lector
            }

        }
        private void buscar()
        {
            //string query = "SELECT * FROM Region WHERE RegionID = @RegionID";
            using (SqlConnection conn = new SqlConnection(clase.clglobales.globales.miconexion))

            {
                SqlCommand cmd = new SqlCommand("SP_buscar_region", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@RegionID", txtID.Text);

                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    this.txtdescripcion.Text = reader["regionDescription"].ToString();
                }
                else
                {
                    MessageBox.Show("No existe la región");
                }
                reader.Close();
            }
        }
        private void btnbuscar_Click(object sender, RoutedEventArgs e)
        {
            clase.Clregiones categ = new clase.Clregiones();
            clase.conexion con = new clase.conexion();
            if (con.Execute(categ.buscartodos(), 0) == true)
            {
                if (con.FieldValue != "")
                {
                    txtID.Text = con.FieldValue;
                    buscar();
                }
            }
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btngrabar_Click(object sender, RoutedEventArgs e)
        {
            //string query = "insert into Region (RegionID,RegionDescription) values (@RegionID,@RegionDescription)";
            //string querybuscar = "select * from Region where RegionID = @RegionID";
            //string querymodificar = "update Region set RegionDescription = @RegionDescription where RegionID = @RegionID";

            using (SqlConnection conn = new SqlConnection(clase.clglobales.globales.miconexion))
            {
                try
                {
                    SqlCommand cmdbuscar = new SqlCommand("SP_buscar_region", conn);
                    cmdbuscar.CommandType = System.Data.CommandType.StoredProcedure;
                    cmdbuscar.Parameters.AddWithValue("@RegionID", txtID.Text);
                    conn.Open();
                    SqlDataReader r = cmdbuscar.ExecuteReader();
                    if (r.Read())
                    {
                        //modificar
                        SqlCommand cmdmodificar = new SqlCommand("SP_modifica_region", conn);
                        cmdmodificar.CommandType = System.Data.CommandType.StoredProcedure;
                        cmdmodificar.Parameters.AddWithValue("@RegionID", txtID.Text);
                        cmdmodificar.Parameters.AddWithValue("@RegionDescription", txtdescripcion.Text);
                        r.Close();
                        cmdmodificar.ExecuteNonQuery();
                        MessageBox.Show("Dato modificado con éxito");
                    }
                    else
                    {
                        r.Close();
                        SqlCommand cmdgrabar = new SqlCommand("SP_graba_region", conn);
                        cmdgrabar.CommandType = System.Data.CommandType.StoredProcedure;
                        cmdgrabar.Parameters.AddWithValue("@RegionID", txtID.Text);
                        cmdgrabar.Parameters.AddWithValue("@RegionDescription", txtdescripcion.Text);
                        cmdgrabar.ExecuteNonQuery();
                        MessageBox.Show("Guardado con éxito");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocurrió un error: " + ex.Message);
                }
            }
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("¿Seguro que deseas borrar el registro?", "Borrar", MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                string queryborrar = "DELETE FROM Region WHERE RegionID = @RegionID"; // Corregido a 'RegionID'

                using (SqlConnection conn = new SqlConnection(clase.clglobales.globales.miconexion))
                {
                    SqlCommand cmdborrar = new SqlCommand(queryborrar, conn);
                    cmdborrar.Parameters.AddWithValue("@RegionID", txtID.Text);

                    conn.Open();

                    int rowsAffected = cmdborrar.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Registro borrado exitosamente.");
                        txtID.Clear();
                        txtdescripcion.Clear();
                        cargarfolio();
                    }
                    else
                    {
                        MessageBox.Show("No se encontró el registro a borrar.");
                    }
                }
            }
        }

    }
}

