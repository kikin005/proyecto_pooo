﻿using proyectospoo23030709.clase;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace proyectospoo23030709.dato
{
    /// <summary>
    /// Lógica de interacción para FMRpaqueteria.xaml
    /// </summary>
    public partial class FMRpaqueteria : Window
    {
       
        public FMRpaqueteria()
        {
            InitializeComponent();
            cargarfolio();
        }
        private void cargarfolio()
        {
            string query = "select max(shipperID)+1 as folio from Shippers";
            using (SqlConnection conn = new SqlConnection(clase.clglobales.globales.miconexion))
            {
                SqlCommand cmd = new SqlCommand(query, conn);

                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    // Asignar valores a las propiedades de la clase
                    this.txtID.Text = reader["Folio"].ToString();
                }
                reader.Close();
            }
        }

        private void btngrabar_Click(object sender, RoutedEventArgs e)
        {
            Grabar();
        }

        private void Grabar()
        {
            try
            {
                clase.Clpaqu B = new clase.Clpaqu (byte.Parse(txtID.Text), txtname.Text, txtphone.Text);
                DataSet ds = new DataSet();
                clase.conexion c = new clase.conexion(B.consultari());
                ds = c.consultar();
                clase.Clpaqu G = new clase.Clpaqu(byte.Parse(txtID.Text), txtname.Text, txtphone.Text);
                c = new clase.conexion();
                if (ds.Tables["Tabla"].Rows.Count > 0)
                {
                    MessageBox.Show(c.EJECUTAR(G.modificar(),G.Shipperid1, G.Companyname1, G.Phone1));
                }

                else
                {

                    MessageBox.Show(c.EJECUTAR(G.graba(),G.Companyname1, G.Phone1));
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex.Message);
            }
        }


        private void buscar()
        {
            string query = "SELECT * FROM Shippers WHERE ShipperID = @ShipperID";
            using (SqlConnection conn = new SqlConnection(clase.clglobales.globales.miconexion))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ShipperID", txtID.Text);

                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    // Asignar valores a las propiedades de la clase
                    this.txtname.Text = reader["CompanyName"].ToString();
                    this.txtphone.Text = reader["phone"].ToString();
                }
                else
                {
                    MessageBox.Show("No existe el shipper con el ID especificado.");
                }
                reader.Close();
            }

        }
    
        private void btnbuscar_Click(object sender, RoutedEventArgs e)
        {
            clase.Clpaqu categ = new clase.Clpaqu();
            clase.conexion con = new clase.conexion();
            if (con.Execute(categ.buscartodos(), 0) == true)
            {
                if (con.FieldValue != "")
                {
                    txtID.Text = con.FieldValue;
                    buscar();
                }
            }
        }

        private void btnsalir_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
