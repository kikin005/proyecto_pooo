﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace proyectospoo23030709.dato
{
    /// <summary>
    /// Lógica de interacción para FRMcategoriasxaml.xaml
    /// </summary>
    public partial class FRMcategoriasxaml : Window
    {
        public FRMcategoriasxaml()
        {
            InitializeComponent();
            cargarfolio();
        }
        //private string miconexion = "Data Source=SERGIOMG\\SQLEXPRESS;Initial Catalog=NORTHWIND;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";
        private void cargarfolio()
        {
            string query = "select max(CategoryID)+1 as folio from Categories";
            using (SqlConnection conn = new SqlConnection(clase.clglobales.globales.miconexion))
            {
                SqlCommand cmd = new SqlCommand(query, conn);

                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    // Asignar valores a las propiedades de la clase
                    this.txtID.Text = reader["Folio"].ToString();
                }
                reader.Close();
            }
        }
        public void buscar()
        {
            string query = "SELECT * FROM Categories WHERE CategoryId = @CategoryId";
            using (SqlConnection conn = new SqlConnection(clase.clglobales.globales.miconexion))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@CategoryId", txtID.Text);

                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    // Asignar valores a las propiedades de la clase
                    this.txtnombre.Text = reader["CategoryName"].ToString();
                    this.txtdescripcion.Text = reader["Description"].ToString();
                }
                else
                {
                    MessageBox.Show("no existe la categoria");
                }
                reader.Close();
            }
        }
        private void btnbuscar_Click(object sender, RoutedEventArgs e)
        {
            clase.CLcategorias categ = new clase.CLcategorias();
            clase.conexion con = new clase.conexion();
            if (con.Execute(categ.buscartodos(),0 )== true)
            {
                if (con.FieldValue != "")
                {
                    txtID.Text = con.FieldValue;
                    buscar();
                }
            }
        }

        private void btngrabar_Click(object sender, RoutedEventArgs e)
        {
            string query = "SELECT * FROM Categories WHERE CategoryId = @CategoryId";
            string querygrabar = "INSERT INTO CATEGORIES (CategoryName, Description) VALUES (@CategoryName, @Description)";
            string querymodificar = "UPDATE Categories SET CategoryName = @CategoryName, Description = @Description WHERE CategoryId = @CategoryId";

            using (SqlConnection conn = new SqlConnection(clase.clglobales.globales.miconexion))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@CategoryId", txtID.Text);  // Consider converting txtID.Text to int if necessary

                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    // Cerrar el lector antes de modificar
                    reader.Close();

                    // Modificar categoría existente
                    SqlCommand cmdmodificar = new SqlCommand(querymodificar, conn);
                    cmdmodificar.Parameters.AddWithValue("@CategoryName", txtnombre.Text);
                    cmdmodificar.Parameters.AddWithValue("@Description", txtdescripcion.Text);
                    cmdmodificar.Parameters.AddWithValue("@CategoryId", txtID.Text);  // Consider int.Parse(txtID.Text) if CategoryId is an integer

                    cmdmodificar.ExecuteNonQuery();
                }
                else
                {
                    // Cerrar el lector antes de insertar
                    reader.Close();

                    // Grabar nueva categoría
                    SqlCommand cmdgrabar = new SqlCommand(querygrabar, conn);
                    cmdgrabar.Parameters.AddWithValue("@CategoryName", txtnombre.Text);
                    cmdgrabar.Parameters.AddWithValue("@Description", txtdescripcion.Text);

                    cmdgrabar.ExecuteNonQuery();
                    MessageBox.Show("registro guardado correctamente");
                    txtdescripcion.Clear();
                    txtnombre.Clear();
                    cargarfolio();
                }
                reader.Close ();
            }

            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // Mostrar cuadro de diálogo de confirmación en WPF
            MessageBoxResult result = MessageBox.Show("¿Seguro que deseas borrar el registro?", "Borrar", MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                string queryborrar = "DELETE FROM Categories WHERE CategoryId = @CategoryId";

                using (SqlConnection conn = new SqlConnection(clase.clglobales.globales.miconexion))
                {
                    SqlCommand cmdborrar = new SqlCommand(queryborrar, conn);
                    cmdborrar.Parameters.AddWithValue("@CategoryId", txtID.Text);

                    conn.Open();

                    int rowsAffected = cmdborrar.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Registro borrado exitosamente.");
                        txtID.Clear();
                        txtnombre.Clear();
                        txtdescripcion.Clear();
                        cargarfolio();
                    }
                    else
                    {
                        MessageBox.Show("No se encontró el registro a borrar.");
                    }
                }
            }
            else
            {
                // El usuario seleccionó "No"
                MessageBox.Show("Borrado de registro cancelado.");
            }
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}