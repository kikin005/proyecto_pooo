﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace proyectospoo23030709
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void misalir_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void misumar_Click(object sender, RoutedEventArgs e)
        {
            practicas.wpfsuma X = new practicas.wpfsuma();
            X.Show();
        }

        private void micategorias_Click(object sender, RoutedEventArgs e)
        {
            dato.FRMcategoriasxaml X = new dato.FRMcategoriasxaml();
            X.Show();
        }

        private void MenuItem_Click()
        {

        }

        private void data_bases_Click(object sender, RoutedEventArgs e)
        {
           dato.FRMcategoriasxaml X = new dato.FRMcategoriasxaml();
            X.Show();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            dato.FRMregiones X = new dato.FRMregiones();
            X.Show();
        }

        private void mipaqueteria_Click(object sender, RoutedEventArgs e)
        {
            dato.FMRpaqueteria x = new dato.FMRpaqueteria();
            x.Show();
        }
    }
}
