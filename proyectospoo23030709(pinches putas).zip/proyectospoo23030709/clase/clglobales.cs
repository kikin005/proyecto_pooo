﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proyectospoo23030709.clase
{
    internal class clglobales
    {
        public static class globales
        {
            //cambio para probar
            static public string dbn = "CEDOTOYA";
            static public string server = "LAPTOP-348QMSO7";
            static public string Password = "";
            static public string seguridad = "Integrated Security=True";
            static public string UserID = "Administrador";
            static public string miconexion = @"Data Source=SERGIOMG\SQLEXPRESS;Initial Catalog=NORTHWIND;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";
        }
    }
}
