﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proyectospoo23030709.clase
{
    internal class Clpaqu
    {
        //campos ** el como es
        private int shipperid;
        private string companyname;
        private string phone;

        public string Companyname1 { get => companyname; set => companyname = value; }
        public string Phone1 { get => phone; set => phone = value; }
        public int Shipperid1 { get => shipperid; set => shipperid = value; }

        public Clpaqu()
        {

        }

        public Clpaqu(int shipperid, string companyname, string phone)
        {
            this.shipperid = shipperid;
            this.companyname = companyname;
            this.phone = phone;
        }

        public Clpaqu(int shipperid)
        {
            this.shipperid = shipperid;
        }

        public Clpaqu(string companyname, string phone)
        {
            this.companyname = companyname;
            this.phone = phone;
        }

        public string buscartodos()
        {
            return ("select * from Shippers");
        }
        public string graba()
        {
            return ("sp_grabar_paq");
        }
        public string consultari()
        {
            return ("select * from shippers where ShipperID = '" +this.shipperid+"'");
        }
        public string modificar()
        {
            return ("sp_modifica_paqueteria");
        }

    }   
}    

    

