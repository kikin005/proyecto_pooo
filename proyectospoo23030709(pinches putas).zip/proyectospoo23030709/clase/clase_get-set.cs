﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practicas02
{
    internal class Class1
    {
        //como es (caracteristicas,campos)
        public decimal valor1;
        public decimal valor2;

        public Class1(decimal valor1, decimal valor2)
        {
            this.valor1 = valor1;
            this.valor2 = valor2;
        }

        public Class1()
        {
        }

        //propiedades get,set

        //constructores

        //lo que hace (acccion)
        public decimal suma()
        {
            return (valor1 + valor2);
        }
        public decimal resta()
        {
            return (valor1 - valor2);
        }
        public decimal multiplicacion()
        {
            return (valor1 * valor2);
        }
        public decimal division()
        {
            return (valor1 / valor2);
        }
    }
}
