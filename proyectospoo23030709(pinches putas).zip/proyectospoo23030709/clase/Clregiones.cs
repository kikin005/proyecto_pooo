﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proyectospoo23030709.clase
{
    internal class Clregiones
    {
        private int regionid;
        private string regionname;



        public Clregiones()
        {
            //buscar todo
        }
        public Clregiones(int regionid)
        {
            //busqueda individuales
            this.regionid = regionid;
        }

        public Clregiones(int regionid, string regionname)
        {
            this.regionid = regionid;
            this.regionname = regionname;
        }

        public string buscartodos()
        {
            return ("select * from region");
        }
    }
}
